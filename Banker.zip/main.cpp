#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <iomanip>
#include "Admin.h"
#include "Banker.h"
#include "Customer.h"

using namespace std;

// Declare global variables 
ifstream acct_in;
ofstream acct_out;

int  *nullptr = NULL;

// Function Prototypes 
void main_menu(Customer* all_customers, Admin* all_admin, Banker* all_bankers, int* num_of_cust, int* num_of_bankers, int* num_of_admin);






// Main Menu definition *******************************************************************
void main_menu(Customer* all_customers, Admin* all_admin, Banker* all_bankers, int* num_of_cust, int* num_of_bankers, int* num_of_admin) 
{
	int admins = 0, bankers = 0, user = -1, client_id, security_code, comma, comma_next, bday, bmon, byear, i;
	string password, PW_string, FNAME, LNAME, STREET, CITY, STATE;
    double checking, saving;
    
	string all_records[100];
	
    ifstream acct_in;
    // ofstream acct_out;
       
    acct_in.open("account_record.txt");       // Open accounts file containing all account records
                              
    /* 
    Source reference: basic_istream::operator >> 
    CPlusplus.com - C++ Reference
    http://www.cplusplus.com/reference/istream/basic_istream/operator%3E%3E/
    
    Purpose: Use of stringstream for syntax to convert string to integer
    
    */  
    i = 0;
    while( getline(acct_in, all_records[i]))  // Read in all user account records and populate class arrays.
    {
           // Sort through each record for data ****************
           
           // cout << all_records[i] << endl;
           stringstream ID_string(all_records[i].substr(0, 4));
           comma = all_records[i].find(",",0,1);
           comma_next = all_records[i].find(",",comma+1,1);
           PW_string = all_records[i].substr(comma+1, comma_next - (comma+1));
           comma = comma_next;
           comma_next = all_records[i].find(",",comma+1,1);
           stringstream SEC_string(all_records[i].substr(comma+1, comma_next - (comma+1)));
           comma = comma_next;
           comma_next = all_records[i].find(",",comma+1,1);
           FNAME = all_records[i].substr(comma+1, comma_next - (comma+1));
           comma = comma_next;
           comma_next = all_records[i].find(",",comma+1,1);
           LNAME = all_records[i].substr(comma+1, comma_next - (comma+1)); 
           comma = comma_next;
           comma_next = all_records[i].find(",",comma+1,1);
           STREET = all_records[i].substr(comma+1, comma_next - (comma+1));                     
           comma = comma_next;
           comma_next = all_records[i].find(",",comma+1,1);
           CITY = all_records[i].substr(comma+1, comma_next - (comma+1));
           comma = comma_next;
           comma_next = all_records[i].find(",",comma+1,1);
           STATE = all_records[i].substr(comma+1, comma_next - (comma+1)); 
           comma = comma_next;
           comma_next = all_records[i].find(",",comma+1,1);
           stringstream BDAY_string(all_records[i].substr(comma+1, comma_next - (comma+1)));
           comma = comma_next;
           comma_next = all_records[i].find(",",comma+1,1);
           stringstream BMON_string(all_records[i].substr(comma+1, comma_next - (comma+1)));
           comma = comma_next;
           comma_next = all_records[i].find(",",comma+1,1);
           stringstream BYEAR_string(all_records[i].substr(comma+1, comma_next - (comma+1)));
           comma = comma_next;
           comma_next = all_records[i].find(",",comma+1,1);
           stringstream CHECK_string(all_records[i].substr(comma+1, comma_next - (comma+1)));           
           comma = comma_next;
           comma_next = all_records[i].find(",",comma+1,1);
           stringstream SAV_string(all_records[i].substr(comma+1, 13));           
           
           // Integer and floating point element conversions from string data types:
           ID_string >> client_id; 
           SEC_string >> security_code;
           BDAY_string >> bday;
           BMON_string >> bmon;
           BYEAR_string >> byear;
           CHECK_string >> checking; // (type double)
           SAV_string >> saving;     // (type double)
           
           /*
           Other string record elements:
                 PW_string: password
                 FNAME: first name
                 LNAME: last name
                 STREET: street address
                 CITY: customer city
                 STATE: customer state
           */      
           

           // Store values in class array pointer for all accounts.
           all_customers -> setID(client_id);
           all_customers -> setAccountPassword(PW_string);
           all_customers -> setSecurity(security_code);
           all_customers -> setFullName(FNAME, LNAME);
           all_customers -> setAddress(STREET + ", " + CITY + ", " + STATE);
           all_customers -> setBirthDate(bday, bmon, byear);
           all_customers -> setChecking(checking);
           all_customers -> setSaving(saving);
           
           all_customers++;   // Increment "accounts array" for all customers
           
           // Store values in class array pointer for all Bankers
           if(security_code == 1)
           {
              all_bankers -> setID(client_id);
              all_bankers -> setAccountPassword(PW_string);
              all_bankers++;
              bankers++;
              
           }
           
           // Store values in class array pointer for all Adminstrators
           if(security_code == 2)
           {
              all_admin -> setID(client_id);
              all_admin -> setAccountPassword(PW_string);
              all_admin++;
              admins++;
              
           }           
              

           i++;  // Increment main tracker counter for all accounts
                
    }
    
    
    // Store account tracker values
    *num_of_cust = i;  
    *num_of_bankers = bankers;
    *num_of_admin = admins;

    // Close account file: "account_record.txt"
    acct_in.close();    

    
	/*
	
	// Login screen *************************
	cout << "\n\n\n                       ===== Capitol One ATM ====="
		 << "\n"                
		 << "\n                             Login ID: ";

	cin >> client_id;

    cout << "\n\n                             Password: ";
    cin >> password;
 
    // Verify Customer input *****************
    for (int cnt=0; cnt < i; cnt++)
    {
        if (all_records[cnt].
    
    */
    
    
    

}


int main() // Program entry point ************************************************************
{
    // Initialize counters to track the number of accounts
	int number_of_customers = 0, number_of_bankers = 0, number_of_admin = 0;

    // For user input from the main menu
    int client_id, user = -1, PASS = 0;
    string password, client;  
    
	// Create class array for all users (EVERYBODY HAS AN ACCOUNT) 
    Customer all_customers[100];
	Customer* customers;
	customers = &all_customers[0];
	
	// Create class array for all administrator accounts (Only 10 accounts max)
    Admin all_admin[10];
	Admin* admins;
	admins = &all_admin[0];

	// Create class array for all banker accounts (Only 20 accounts max)
    Banker all_bankers[20];
	Banker* bankers;
	bankers = &all_bankers[0];
	

	
    // Go to Main Menu and upload all account information into User classes 	
	main_menu(all_customers, all_admin, all_bankers, &number_of_customers, &number_of_bankers, &number_of_admin);
	
	/*
	cout << "Number of customers: " << number_of_customers << "\n"
         << all_admin[0].getAccountName() << "\n"
         << all_customers[0].getFullName() << "\n"
         << all_bankers[0].getAccountName() << endl;
    */ 
     
     
    system("CLS");   
    	
	// Login screen *************************
	cout << "\n\n\n                       ===== Capitol One ATM ====="
		 << "\n"                
		 << "\n                             Login ID: ";
	cin >> client;

    cout << "\n\n                             Password: ";
    cin >> password;
    
    stringstream ID_string(client);  // Convert to integer 
    ID_string >> client_id;
 
 
    // Verify Customer input *****************
    for (int cnt=0; cnt < number_of_customers; cnt++)
    {
        if (all_customers[cnt].getID() == client_id && all_customers[cnt].getAccountPassword() == password)
            user = cnt;
         
    }
    
    
    // Re-enter information if the ID and Password are incorrect
    if (user == -1)
    {
       cout << "\n\n                     Login ID or Password is incorrect.\n\n";
       system("PAUSE");
       
       do
       {
 
	         system("CLS"); 
             fflush(stdin);  
    	
	         // Login screen *************************
             cout << "\n\n\n                       ===== Capitol One ATM ====="
		          << "\n"                
		          << "\n                             Login ID: ";
	              cin >> client;
	        
             cout << "\n\n                             Password: ";
             cin >> password;
             
             stringstream ID_string(client);
             ID_string >> client_id;
        
             // Verify Customer input again *****************
             for (int cnt=0; cnt < number_of_customers; cnt++)
             {
                 if (all_customers[cnt].getID() == client_id && all_customers[cnt].getAccountPassword() == password)
                 {
                    user = cnt;
                    PASS = 1;
                 }
             } // End of For loop
             
             if (user == -1)
             {
                cout << "\n\n                     Login ID or Password is incorrect.\n\n";
                system("PAUSE");
                // fflush(stdin);
             }
             
       } while (!PASS);
       
    }  // End of "IF" block (Re-entry block)
	
	
	
    cout << "\n\nUser index within class array: " << user << endl;
	system("PAUSE");	
	
	
	return 0;
}
